const Joi = require('joi');
const { PHONE_REGEX } = require('../constants/contants');

const registerValidation = Joi.object({
  email: Joi.string().email().trim().lowercase()
    .required(),
  password: Joi.string().trim().min(6).required(),
  name: Joi.string().trim().required()
});

module.exports = registerValidation;
