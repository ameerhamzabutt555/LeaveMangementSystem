const Joi = require('joi');
const { PHONE_REGEX } = require('../constants/contants');

const loginValidation = Joi.object({
  email: Joi.string().email().lowercase(),
  password: Joi.string().trim().min(6).required(),
})

module.exports = loginValidation;
