const express = require('express');

const router = express.Router();

const userRouter = require('../components/users/users.api');

router.use('/user', userRouter);

module.exports = router;
