/* eslint-disable no-console */
const mongoose = require('mongoose');
const { DBNAME } = require('../utils/config');
console.log(DBNAME)
const MONGODB_URI = `mongodb://localhost:27017/${DBNAME}`;
console.log(MONGODB_URI);
mongoose.connect(MONGODB_URI)
  .then(() => console.log('Database connection successfull'))
  .catch((err) => console.log('Errror connecting to the databse', err));
