const mongoose = require('mongoose');
const MUUID = require('uuid-mongodb');

const leaveSchema = new mongoose.Schema({
    _id: {
        type: 'object',
        value: { type: 'Buffer' },
        default: () => MUUID.v4(),
    },
    email: {
        type: String,
        trim: true,
        required: true,
    },
    name: {
        type: String,
        trim: true,
        required: true,
    },
    leaves: {
        type: String,
        trim: true,
        required: true,
    },
    status: {
        type: String,
        trim: true,
    },
    type: {
        type: String,
        trim: true,
        required: true,
    }, from: {
        type: String,
        trim: true,
        required: true,
    }, to: {
        type: String,
        trim: true,
        required: true,
    },
    createdAt: {
        type: Date,
        default: new Date(),
    },
    updatedAt: {
        type: Date,
    },
});

const Leave = mongoose.model('leave', leaveSchema);

module.exports = Leave;
