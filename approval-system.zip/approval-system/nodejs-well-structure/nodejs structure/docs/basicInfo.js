module.exports = {
  openapi: '3.0.3', // present supported openapi version
  info: {
    title: 'One Money Way API', // short title.
    description: 'APIs realted to One Money Way ', //  desc.
    version: '1.0.0', // version number
    contact: {
      name: 'moeez', // your name
      email: 'moeez.ahmed@txend.com', // your email
      url: '', // your website
    },
  },
};
