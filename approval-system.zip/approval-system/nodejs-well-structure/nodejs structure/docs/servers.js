module.exports = {
  servers: [
    {
      url: 'http://localhost:3001', // url
      description: 'Local server', // name
    },
  ],
};
