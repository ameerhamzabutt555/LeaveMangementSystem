module.exports = {
  tags: [
    {
      name: 'test CRUD operations', // name of a tag
    },
  ],
};
