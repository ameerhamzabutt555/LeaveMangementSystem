/**
 * this file will contain all the helpers functions
 * which needs to be shared among the components
 */


const jwt = require('jsonwebtoken');

// This should be in your environment variables, not hard-coded in production
const SECRET_KEY = 'sec'; // Use environment variable in production
const expiresIn = '1h'; // Token expiration time

/**
 * Generates a JWT token for a given user object.
 * @param {Object} user - The user object for which to generate the token. Typically contains user ID.
 * @returns {String} Returns a JWT token as a string.
 */
function generateToken(user) {
    // Ensure the user object has the required properties, e.g., user.id
    if (!user || !user.id) {
        throw new Error('Invalid user object');
    }
    // Create the token payload
    const payload = {
        id: user._id, // Include any other user details you want in the payload
        email: user.email, // Example additional information
        role: user.role === undefined ? "client" : user.role,
        name: user.name
    };
    console.log(payload)

    // Sign the token with your secret
    const token = jwt.sign(payload, SECRET_KEY, { expiresIn: expiresIn });

    return token;
}

module.exports = {
    generateToken
};
