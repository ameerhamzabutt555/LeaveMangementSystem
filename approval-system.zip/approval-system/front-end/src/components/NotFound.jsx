import Navs from "./Navs";
import "../assets/css/notfound.css";

function NotFound() {
  return (
    <>
      <div class="container-notfound">
        <h1>404 Not Found</h1>
        <p>Oops! The page you're looking for doesn't exist.</p>
        <p>
          <a href="/">Go back home</a> or use the menu to navigate.
        </p>
      </div>
    </>
  );
}

export default NotFound;
