import React, { useEffect, useState } from "react";
import Navs from "./Navs";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { userService } from "../Api";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

function Charts() {
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: "Sick Leaves",
        data: [],
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 1,
      },
      {
        label: "Annual Leaves",
        data: [],
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
      {
        label: "Casual Leaves",
        data: [],
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  });

  useEffect(() => {
    async function fetchLeaves() {
      try {
        const result = await userService.filterLeaves({});
        const leavesData = result.userInfo || result; // Fallback to result if userInfo is not a key
        if (!Array.isArray(leavesData)) {
          throw new Error("Data received is not an array");
        }

        const usersData = {};
        leavesData.forEach((leave) => {
          const { name, type, leaves } = leave;
          if (!usersData[name]) {
            usersData[name] = { sick: 0, annual: 0, casual: 0 };
          }
          usersData[name][type] += parseInt(leaves, 10);
        });

        const names = Object.keys(usersData);
        const sickData = names.map((name) => usersData[name].sick);
        const annualData = names.map((name) => usersData[name].annual);
        const casualData = names.map((name) => usersData[name].casual);

        setChartData({
          labels: names,
          datasets: [
            { ...chartData.datasets[0], data: sickData },
            { ...chartData.datasets[1], data: annualData },
            { ...chartData.datasets[2], data: casualData },
          ],
        });
      } catch (error) {
        console.error("Error fetching leaves data:", error);
      }
    }

    fetchLeaves();
  }, []);

  const options = {
    plugins: {
      legend: {
        display: true,
      },
      title: {
        display: true,
        text: "User Leaves Overview",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      },
    },
  };

  return (
    <>
      <Navs />
      <div style={{ maxWidth: "800px", margin: "auto", paddingTop: "20px" }}>
        <Bar data={chartData} options={options} />
      </div>
    </>
  );
}

export default Charts;
