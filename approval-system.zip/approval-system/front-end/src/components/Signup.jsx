import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import "../assets/css/Login.css";
import { useNavigate } from "react-router-dom";
import { userService } from "../Api";
import Swal from "sweetalert2";

function Signup() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async (event) => {
    event.preventDefault(); // Prevent the default form submission behavior
    try {
      const userData = { email, name, password };
      console.log(userData);
      await userService.createUser(userData); // Call the API to register the user
      Swal.fire({
        title: "Good job!",
        text: "User Registered Successfully!",
        icon: "success",
      });
      navigate("/"); // Navigate to homepage or login page upon successful registration
    } catch (error) {
      console.error("Failed to register:", error);
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "User Already Registered!",
      });
    }
  };

  const isDisabled = email.length < 5 || password.length < 6 || name.length < 3;

  return (
    <div className="main-container">
      <h1 className="top-text">SignUp</h1>
      <div className="form-container">
        <Form onSubmit={handleRegister}>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Name </Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Form.Group>
          <Button variant="primary" type="submit" disabled={isDisabled}>
            Register
          </Button>
          <Button
            variant="primary"
            onClick={() => navigate("/")} // Change to navigate to login page
            style={{ marginLeft: "5px" }}
            disabled={!isDisabled}
          >
            Login
          </Button>
        </Form>
      </div>
    </div>
  );
}

export default Signup;
