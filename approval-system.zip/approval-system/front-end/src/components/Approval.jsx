import Navs from "./Navs";
import Table from "react-bootstrap/Table";
import { userService } from "../Api";
import { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Button from "react-bootstrap/Button";

function Approval() {
  const navigate = useNavigate();
  const user = useSelector((state) => state.user.user);
  // const auth = useSelector((state) => state.user.isAuthenticated);
  // auth === false && localStorage.removeItem("Token");
  // console.log("yyyyyyyyyyyyyyyy", auth);
  const [LeavesList, setLeaves] = useState([]);
  useEffect(() => {
    const fetchLeaves = async () => {
      const allLeaves = await userService.filterLeaves({
        status: "",
      });
      setLeaves(allLeaves.userInfo);
    };
    user.role !== "admin" && navigate("/dashboard");
    // Call the async function
    fetchLeaves();
  }, []);

  const handleStatusChange = async (newStatus, index, id) => {
    console.log(
      `Status for index ${index} changed to ${newStatus}=======>${id}`
    );
    const statusChange = await userService.leavesStatusChange(
      { status: newStatus },
      id
    );
    console.log("reeeeeeeeeee", statusChange);
    // Here you can implement further logic to update the status in your backend
  };

  const handleDeleteLeave = async (index, id) => {
    console.log(`Status for index ${index} changed to =======>${id}`);
    const deleted = await userService.leavesDeleted(id);
    console.log("reeeeeeeeeee", deleted);
    const updatedItems = LeavesList.filter(
      (item, itemIndex) => index !== itemIndex
    );
    setLeaves(updatedItems);
    // Here you can implement further logic to update the status in your backend
  };

  return (
    <>
      <Navs />
      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Leaves</th>
              <th>Leave Type</th>
              <th>Apply At</th>
              <th>From</th>
              <th>To</th>
              <th>Approval</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {LeavesList.map((item, index) => (
              <tr key={index}>
                <td>{index}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.leaves}</td>
                <td>{item.type}</td>
                <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                <td>{item.from}</td>
                <td>{item.to}</td>
                <td>
                  <Form.Select
                    aria-label="Default select example"
                    // value={item.approvalStatus}
                    onChange={(e) =>
                      handleStatusChange(e.target.value, index, item._id)
                    }
                  >
                    <option>
                      {item.status.charAt(0).toUpperCase() +
                        item.status.slice(1).toLowerCase()}
                    </option>
                    {item.status === "pending" ? (
                      ""
                    ) : (
                      <option value="pending">Pending</option>
                    )}
                    {item.status === "approved" ? (
                      ""
                    ) : (
                      <option value="approved">Approved</option>
                    )}
                    {item.status === "rejected" ? (
                      ""
                    ) : (
                      <option value="rejected">Rejected</option>
                    )}
                  </Form.Select>
                </td>
                <td>
                  <Button
                    variant="danger"
                    onClick={() => handleDeleteLeave(index, item._id)}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
}

export default Approval;
