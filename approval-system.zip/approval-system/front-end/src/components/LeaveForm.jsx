// import Button from "react-bootstrap/Button";
// import Form from "react-bootstrap/Form";
import { Form, Button, Row, Col } from "react-bootstrap";
import { useState } from "react";
import "../assets/css/form.css";
import { userService } from "../Api";
import Swal from "sweetalert2";

function LeaveForm() {
  const [email, setEmail] = useState("");
  const [leave, setLeave] = useState("");
  const [name, setName] = useState("");
  const [leaveType, setLeaveType] = useState("");
  const [validated, setValidated] = useState(false);
  const [startDate, setStartDate] = useState(""); // New state for the date
  const [endDate, setEndDate] = useState(""); // New state for the date

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (event.currentTarget.checkValidity() === false) {
      event.stopPropagation();
    } else {
      Swal.fire({
        title: "Are you sure?",
        text: "You want to submit the leave!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Regester it!",
      }).then((result) => {
        if (result.isConfirmed) {
          userService.leaveRegister({
            email,
            leave,
            leaveType,
            startDate,
            endDate,
            name,
          });
          Swal.fire({
            title: "Submitted!",
            text: "Your file has been Submitted.",
            icon: "success",
          });
        }
      });
    }
    setValidated(true);
  };
  const isDisabled =
    email.length < 5 ||
    leave.length < 1 ||
    leaveType.length < 2 ||
    name.length < 1;

  return (
    <>
      <div className="form">
        <h2
          style={{
            textAlign: "center",
            paddingBottom: "26px",
            fontFamily: "Dalton Maag",
          }}
        >
          Apply for the Leave
        </h2>
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
          <Row className="mb-3">
            <Col md={6}>
              <Form.Group className="mb-3" controlId="formBasicLeave">
                <Form.Control
                  type="text"
                  placeholder="Enter Name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="formBasicEmail">
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row className="mb-3">
            <Col md={6}>
              <Form.Group className="mb-3" controlId="formBasicLeaveType">
                <Form.Select
                  aria-label="Default select example"
                  style={{ border: "none", borderBottom: "2px solid #ccc" }}
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value)}
                >
                  <option>Select Leave Type</option>
                  <option value="sick">Sick</option>
                  <option value="annual">Annual</option>
                  <option value="casual">Casual</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3" controlId="formBasicLeave">
                <Form.Control
                  type="text"
                  placeholder="Enter Leaves in counting"
                  required
                  value={leave}
                  onChange={(e) => setLeave(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col md={6}>
              <Form.Group className="mb-3" controlId="formStartDate">
                <Form.Label>To</Form.Label>
                <Form.Control
                  type="date"
                  required
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3" controlId="formStartDate">
                <Form.Label>From</Form.Label>
                <Form.Control
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>

          <Button variant="primary" type="submit" disabled={isDisabled}>
            Submit
          </Button>
        </Form>
      </div>
    </>
  );
}

export default LeaveForm;
