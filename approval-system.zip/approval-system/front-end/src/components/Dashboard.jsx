import LeaveForm from "./LeaveForm";
import Navs from "./Navs";
// import { useSelector } from "react-redux";

function Dashboard() {
  // const auth = useSelector((state) => state.user.isAuthenticated);
  // auth === false && localStorage.removeItem("Token");
  return (
    <>
      <Navs />
      <LeaveForm />
    </>
  );
}

export default Dashboard;
