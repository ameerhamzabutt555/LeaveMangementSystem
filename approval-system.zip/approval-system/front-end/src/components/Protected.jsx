// src/components/ProtectedRoute.js

import React from "react";
import { Navigate } from "react-router-dom";

const isLoggedIn = () => {
  const token = localStorage.getItem("Token");
  return !!token; // Add more sophisticated checks here if needed
};

const Protected = ({ children }) => {
  if (!isLoggedIn()) {
    // Redirect them to the /login page, but save the current location they were
    // trying to go to when they were redirected. This allows us to send them
    // along to that page after they log in, which is a nicer user experience
    // than dropping them off on the home page.
    return <Navigate to="/" replace />;
  }

  return children;
};

export default Protected;
