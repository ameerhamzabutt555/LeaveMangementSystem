import Navs from "./Navs";
import "../assets/css/leaves.css";
import { userService } from "../Api";
import { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
// import { useSelector } from "react-redux";

function LeaveList() {
  const [pendingList, setPendingList] = useState([]);
  const [approvedList, setApprovedLeaves] = useState([]);
  const [rejectedList, setRejectedLeaves] = useState([]);
  // const auth = useSelector((state) => state.user.isAuthenticated);
  // auth === false && localStorage.removeItem("Token");

  useEffect(() => {
    const fetchLeaves = async () => {
      const pendingLeaves = await userService.filterLeaves({
        status: "pending",
      });
      const approvedLeaves = await userService.filterLeaves({
        status: "approved",
      });
      const rejectedLeaves = await userService.filterLeaves({
        status: "rejected",
      });
      setPendingList(pendingLeaves.userInfo);
      setApprovedLeaves(approvedLeaves.userInfo);
      setRejectedLeaves(rejectedLeaves.userInfo);
    };

    // Call the async function
    fetchLeaves();
  }, []);
  return (
    <>
      <Navs />
      <div className="leave-container">
        <div className="list">
          <h5>Pending Leaves</h5>
          <div className="table">
            <Table
              striped
              bordered
              hover
              style={{ fontSize: "12px", fontWeight: "normal" }}
            >
              <thead>
                <tr>
                  <th>#</th>
                  <th>Email</th>

                  <th>Leaves</th>
                  <th>Leave Type</th>
                  <th>Apply At</th>
                </tr>
              </thead>
              <tbody>
                {pendingList.map((item, index) => (
                  <tr key={index}>
                    <td>{index}</td>
                    <td>{item.email}</td>

                    <td>{item.leaves}</td>
                    <td>{item.type}</td>
                    <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
        <div className="list">
          <h5>Approved Leaves</h5>
          <Table
            striped
            bordered
            hover
            style={{ fontSize: "12px", fontWeight: "normal" }}
          >
            <thead>
              <tr>
                <th>#</th>
                <th>Email</th>

                <th>Leaves</th>
                <th>Leave Type</th>
                <th>Apply At</th>
              </tr>
            </thead>
            <tbody>
              {approvedList.map((item, index) => (
                <tr key={index}>
                  <td>{index}</td>
                  <td>{item.email}</td>

                  <td>{item.leaves}</td>
                  <td>{item.type}</td>
                  <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
        <div className="list">
          <h5>Rejected Leaves</h5>
          <Table
            striped
            bordered
            hover
            style={{ fontSize: "12px", fontWeight: "normal" }}
          >
            <thead>
              <tr>
                <th>#</th>
                <th>Email</th>

                <th>Leaves</th>
                <th>Leave Type</th>
                <th>Apply At</th>
              </tr>
            </thead>
            <tbody>
              {rejectedList.map((item, index) => (
                <tr key={index}>
                  <td>{index}</td>
                  <td>{item.email}</td>

                  <td>{item.leaves}</td>
                  <td>{item.type}</td>
                  <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
}

export default LeaveList;
