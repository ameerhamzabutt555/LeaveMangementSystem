import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import Badge from "@mui/material/Badge";
import { styled } from "@mui/material/styles";
import { Dropdown } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";

const StyledBadge = styled(Badge)(({ theme }) => ({
  "& .MuiBadge-badge": {
    backgroundColor: "#44b700",
    color: "#44b700",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "ripple 1.2s infinite ease-in-out",
      border: "1px solid currentColor",
      content: '""',
    },
  },
  "@keyframes ripple": {
    "0%": {
      transform: "scale(.8)",
      opacity: 1,
    },
    "100%": {
      transform: "scale(2.4)",
      opacity: 0,
    },
  },
}));

function Navs() {
  const user = useSelector((state) => state.user.user);
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(false);

  const toggleDropdown = () => setShowDropdown(!showDropdown);

  return (
    <>
      <Navbar bg="primary" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="#">Leave System</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/dashboard">Home</Nav.Link>
            <Nav.Link
              onClick={() => {
                navigate("/leaves");
              }}
            >
              Leaves List
            </Nav.Link>
            {user.role === "admin" ? (
              <Nav.Link
                onClick={() => {
                  navigate("/approval");
                }}
              >
                Approval System
              </Nav.Link>
            ) : (
              ""
            )}
            {user.role === "admin" ? (
              <Nav.Link
                onClick={() => {
                  navigate("/charts");
                }}
              >
                Chart System
              </Nav.Link>
            ) : (
              ""
            )}
          </Nav>
          <Nav>
            <Dropdown show={showDropdown} onToggle={toggleDropdown}>
              <Dropdown.Toggle>
                <StyledBadge
                  overlap="circular"
                  anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                  variant="dot"
                >
                  <Avatar
                    alt="Remy Sharp"
                    src="/src/assets/images/ali.png"
                    sx={{ width: 40, height: 40 }}
                  />
                </StyledBadge>
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item href="#">
                  {user.name.charAt(0).toUpperCase() +
                    user.name.slice(1).toLowerCase()}
                </Dropdown.Item>
                <Dropdown.Item
                  href="/"
                  onClick={() => {
                    localStorage.removeItem("Token");
                  }}
                >
                  Logout
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Nav>
        </Container>
      </Navbar>
    </>
  );
}

export default Navs;
