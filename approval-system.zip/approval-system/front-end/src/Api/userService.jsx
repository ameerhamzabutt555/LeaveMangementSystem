import axios from "axios";

const API_BASE_URL = "http://localhost:2000";

export const fetchUsers = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/user/getAllUsers`);
    console.log("--------->", response);
    return response.data;
  } catch (error) {
    // Handle errors here, possibly a global error handler
    console.error("Failed to fetch users:", error);
    throw error;
  }
};

// Create a new user
export const createUser = async (userData) => {
  try {
    console.log(typeof userData);
    const response = await axios.post(
      `${API_BASE_URL}/user/register`,
      userData
    );
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export const loginUser = async (userData) => {
  try {
    console.log(typeof userData, userData);
    const response = await axios.post(`${API_BASE_URL}/user/login`, userData);
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export const leaveRegister = async (userData) => {
  try {
    console.log(typeof userData, userData);
    const response = await axios.post(
      `${API_BASE_URL}/user/leaves-apply`,
      userData
    );
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export const filterLeaves = async (userData) => {
  try {
    console.log(typeof userData, userData);
    const response = await axios.post(`${API_BASE_URL}/user/filter`, userData);
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export const leavesStatusChange = async (userData, id) => {
  try {
    console.log(typeof userData, userData, id);
    const response = await axios.patch(
      `${API_BASE_URL}/user/status/${id}`,
      userData
    );
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export const tokenVerification = async (token) => {
  try {
    console.log(token);
    const response = await axios.get(`${API_BASE_URL}/user/verify/${token}`);
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    return null;
  }
};
///verify/:token

export const leavesDeleted = async (id) => {
  try {
    console.log("mmmmmmmmmmmm", id);
    const response = await axios.delete(`${API_BASE_URL}/user/delete/${id}`);
    return response.data;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};
