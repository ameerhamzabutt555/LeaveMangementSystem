import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NotFound from "./components/NotFound";
import Dashboard from "./components/Dashboard";
import LeaveList from "./components/LeaveList";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Protected from "./components/Protected";
import Approval from "./components/Approval";
import Charts from "./components/Charts";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <Protected>
                <Dashboard />
              </Protected>
            }
          />
          <Route path="*" element={<NotFound />} />
          <Route
            path="/leaves"
            element={
              <Protected>
                <LeaveList />
              </Protected>
            }
          />
          <Route path="/signup" element={<Signup />} />
          <Route path="/approval" element={<Approval />} />
          <Route path="/charts" element={<Charts />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
